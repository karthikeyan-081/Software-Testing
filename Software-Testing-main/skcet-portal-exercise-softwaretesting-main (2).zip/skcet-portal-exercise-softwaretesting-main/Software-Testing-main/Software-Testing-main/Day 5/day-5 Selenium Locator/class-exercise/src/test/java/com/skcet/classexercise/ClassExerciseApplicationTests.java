package com.skcet.classexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
